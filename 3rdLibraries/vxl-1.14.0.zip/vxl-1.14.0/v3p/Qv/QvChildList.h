#ifndef _QV_CHILD_LIST_
#define _QV_CHILD_LIST_

#include "QvLists.h"

class QvChildList : public QvNodeList {

  public:
    QvChildList();
    ~QvChildList();
};

#endif /* _QV_CHILD_LIST_ */
