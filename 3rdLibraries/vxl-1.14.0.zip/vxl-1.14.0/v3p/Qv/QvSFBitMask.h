#ifndef  _QV_SF_BIT_MASK_
#define  _QV_SF_BIT_MASK_

#include "QvSFEnum.h"

class QvSFBitMask : public QvSFEnum
{
public:
  // Inherits value
  QV_SFIELD_HEADER(QvSFBitMask);
};

#endif /* _QV_SF_BIT_MASK_ */
