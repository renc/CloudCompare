#include "QvTransformSeparator.h"

QV_NODE_SOURCE(QvTransformSeparator);

QvTransformSeparator::QvTransformSeparator()
{
    QV_NODE_CONSTRUCTOR(QvTransformSeparator);
    isBuiltIn = TRUE;
}

QvTransformSeparator::~QvTransformSeparator()
{
}
