#ifndef Qv_pi_h_
#define Qv_pi_h_

#define QV_PI   3.14159265358979323846  // M_PI is not iso standard
#define QV_PI_4 0.78539816339744830962  // M_PI_4 is not iso standard
#define QV_ONE_OVER_PI 0.31830988618379067154

#endif
