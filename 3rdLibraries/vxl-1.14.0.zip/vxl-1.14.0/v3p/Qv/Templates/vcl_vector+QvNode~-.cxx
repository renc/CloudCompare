class QvNode;
#include <vcl_vector.txx>

VCL_VECTOR_INSTANTIATE(QvNode*);
