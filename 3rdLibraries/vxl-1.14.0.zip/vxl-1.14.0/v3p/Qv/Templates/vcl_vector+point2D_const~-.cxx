#include <vcl_vector.txx>

class point2D;
VCL_VECTOR_INSTANTIATE(point2D const*);
