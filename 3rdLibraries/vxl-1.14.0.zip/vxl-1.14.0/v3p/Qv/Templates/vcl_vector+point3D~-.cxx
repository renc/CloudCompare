#include <vcl_vector.txx>

class point3D;
VCL_VECTOR_INSTANTIATE(point3D*);
