#include <vcl_vector.txx>

class vector3D;
VCL_VECTOR_INSTANTIATE(vector3D const*);
